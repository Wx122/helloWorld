
# postman使用流程

###一、postman的操作环境
* postman适用于不同的操作系统，Postman Mac、Windows X32、Windows X64、Linux系统，还支持postman 浏览器扩展程序、postman chrome应用程序等


###二、下载地址
* http://www.pc6.com/mac/224724.html

###三、postman的基础功能
![](1.png)

###四、接口请求流程

#### 1.get请求
GET请求：点击Params，输入参数及value，可输入多个，即时显示在URL链接上，
所以，GET请求的请求头与请求参数如在接口文档中无特别声明时，可以不填。

![](2.png)

#### 2.post请求
下图示例中设置了请求方法，请求URL，请求参数，但是没有设置请求头
在我的使用过程中，请求头是根据请求参数的形式自动生成的
请求头中的Content-Type与请求参数的格式之间是有关联关系，比如：

|post参数格式|content-type|参数示例|
|:---:|:---:|:---:|
| 表单提交 | application/x-www-form-urlencoded | a=1&b=2 | 
| json提交 | application/json  | {"a":"1","password":"2"} | 
| xml提交 | text/xml | <?xml version='1.0' encoding='utf-8'?><book>悟空</book> | 
##### 2.1 post	请求：表单请求
![](3.png)
![](4.png)

##### 2.2 post	请求：json提交
下图中，当我们选择JSON(application/json) 是会自动帮我们设置 headers 为 application/json。

![](5.png)
![](6.png)

raw：仅仅是响应体的一个大文本，可以告诉你响应是否压缩了
#### 2.3 post请求：xml提交
![](7.png)

### 五、管理用例——collections
Collections集合：也就是将多个接口请求可以放在一起，并管理起来
##### 5.1 创建collections
点击上图中的带+号的图标，输入Name:”efg”，Description:”示例demo”，点击Create按钮即创建成功一个Collections.

![](8.png)
![](9.png)

##### 5.2 在collections添加请求
在右侧准备好接口请求的所有数据，并验证后，点击save按钮。

![](10.png)

保存好之后就可以在这里看到啦，之后要再次调用时可以点击这里

![](11.png)

当然文件夹里可以嵌套文件夹

### 六、其他接口测试工具

#### 6.1 jmeter
是一款100%纯Java编写的免费开源的工具，它主要用来做性能测试，相比loadrunner来说，它内存占用小，免费开源，轻巧方便、无需安装
##### 6.1.1 下载地址
官网下载版本步骤：

→打开链接：https://jmeter.apache.org/download_jmeter.cgi

→找到：Apache JMeter 4.0 (Requires Java 8 or 9.)

→找到：Binaries

→选中：apache-jmeter-4.0.zip

→点击下载到任意磁盘，解压到英文目录下。

##### 6.1.2 get请求
![](12.png)
![](13.png)

##### 6.1.3 post请求

![](14.png)

如果需要token时：

![](15.png)
![](16.png)

#### 6.2 RESTClient
RESTClient是火狐的一款插件，可以模拟发送网页请求。

##### 6.2.1 安装插件
在火狐浏览器附加组件搜索“RESTClient”，然后安装

![](17.png)

##### 6.2.2 get请求
例子：URL:http://127.0.0.1:8000/api/get_guest_list/?eid=1&&phone=13511001100

![](18.png)


##### 6.2.3 post请求
(1) 点击Headers,选择Custom Header

(2) 输入Name:Content-Type   Value:application/x-www-form-urlencoded;charset=UTF-8

![](19.png)

选择POST方式，输入Body

例子：URL:http://127.0.0.1:8000/api/get_guest_list/?eid=1&&phone=13511001100

![](20.png)













