# Charles

说明：  
Charles 官网：`https://www.charlesproxy.com/`  

Charles 是在 Mac 下常用的网络封包截取工具，在做移动开发时，我们为了调试与服务器端的网络通讯协议，常常需要截取网络封包来分析。  

Charles 通过将自己设置成系统的网络访问代理服务器，使得所有的网络访问请求都通过它来完成，从而实现了网络封包的截取和分析。  

除了在做移动开发中调试端口外，Charles 也可以用于分析第三方应用的通讯协议。配合 Charles 的 SSL 功能，Charles 还可以分析 Https 协议。

## Charles 主要的功能包括

* 截取 Http 和 Https 网络封包。
* 支持重发网络请求，方便后端调试。
* 支持修改网络请求参数。
* 支持网络请求的截获并动态修改。
* 支持模拟慢速网络。

## Charles安装完成后 将 Charles 设置成系统代理  

启动 Charles 后，第一次 Charles 会请求你给它设置系统代理的权限。你可以输入登录密码授予 Charles 该权限。你也可以忽略该请求，然后在需要将 Charles 设置成系统代理时，选择菜单中的 “Proxy” -> “Mac OS X Proxy” 来将 Charles 设置成系统代理。

![“Proxy”](./images/charles_proxy.jpg)

## Charles启动后的页面

![“window”](./images/charles_window.jpg)

Charles 主要提供两种查看封包的视图，分别名为 “Structure” 和 “Sequence”  

* Structure 视图将网络请求按访问的域名分类。
* Sequence 视图将网络请求按访问的时间排序。

在“Sequence”模式下可以根据filter去根据path中的关键字去筛选接口  

![“filter”](./images/charles_filter.png)

## 过滤网络请求  

方法一：使用filter过滤筛选

方法二：在 Charles 的菜单栏选择 “Proxy”->”Recording Settings”，然后选择 Include 栏，选择添加一个项目，然后填入需要监控的协议，主机地址，端口号。这样就可以只截取目标网站的封包了

![“步骤一”](./images/charles_filter2.png)
![“步骤二”](./images/charles_filter3.png)
![“结果”](./images/charles_filter4.png)

## 抓取手机上的请求

要截取手机上的网络请求，我们首先需要将 Charles 的代理功能打开。在 Charles 的菜单栏上选择 “Proxy”->”Proxy Settings”，填入代理端口 8888，并且勾上 “Enable transparent HTTP proxying” 就完成了在 Charles 上的设置  
![“步骤一”](./images/charles_proxy2.png)
![“步骤二”](./images/charles_proxy3.png)
![“步骤三”](./images/charles_proxy4.png)
![“步骤四”](./images/charles_proxy5.png)
![“步骤五”](./images/charles_proxy6.png)
手机和电脑保持同一网段，在手机wifi找到http代理，配置项改为手动代理，服务器改为电脑的ip，端口号改为刚才修改的8888，电脑上会弹出来一个弹框点击allow，这个时候就可以抓取到手机上的网络请求
![“手机代理效果图”](./images/charles_proxy7.png)

## 抓取请求返回乱码问题

![“步骤一”](./images/charles_error1.jpg)
![“步骤二”](./images/charles_error2.png)
![“步骤三”](./images/charles_error3.png)
![“步骤四”](./images/charles_error4.png)