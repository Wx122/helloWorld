# Mockjs

说明：  
Mockjs 官网：`http://mockjs.com/`  
文档： `https://github.com/nuysoft/Mock/wiki`

Mock.js是一个模拟数据生成器，可以非常方便的模拟后端的数据，也可以轻松的实现增删改查这些操作。

优点：

* 前后端分离
  * 让前端工程师独立于后端开发  
* 开发无侵入  
  * 不需要修改现有代码，就可以拦截Ajax请求，返回模拟响应数据
* 数据类型丰富
  * 支持生成随机的文本、数字、布尔值、日期、邮箱、链接、图片、颜色等
* 增加单元测试的真实性
  * 通过随机数据，模拟各种场景
* 用法简单
  * 符合直觉的接口
* 方便扩展
  * 支持扩展更多数据类型，支持自定义函数和正则

## Mock.js 的语法规范包括两部分

* 数据模板定义规范（Data Template Definition，DTD）
* 数据占位符定义规范（Data Placeholder Definition，DPD）

### 数据模板中的每个属性由 3 部分构成：属性名、生成规则、属性值：

``` 数据模板的组成
  // 属性名   name
  // 生成规则 rule
  // 属性值   value
  'name|rule': value
```

## 基础语法使用

### 属性值是字符串 String

* 'name|min-max': string
  * 限制重复的最少次数和重复的最多次数

![“mock”](./images/mock01.png)

* 'name|count': string
  * 字符循环的次数

![“mock”](./images/mock02.png)

### 属性值是数字 Number

* name|+1': number
  * 属性值自动加 1，初始值为 number 可以作为id

![“mock”](./images/mock04.png)

* 'name|min-max': number
  * 生成一个在min-max区间内的数值

![“mock”](./images/mock03.png)

* 'name|min-max.dmin-dmax': number
  * 生成一个浮点数，整数部分大于等于 min、小于等于 max，小数部分保留 dmin 到 dmax 位。

![“mock”](./images/mock05.png)

### 属性值是布尔型 Boolean

* 'name|1': boolean
  * 随机生成一个布尔值，值为 true 的概率是 1/2，值为 false 的概率同样是 1/2。

![“mock”](./images/mock06.png)

* 'name|min-max': value
  * 随机生成一个布尔值，值为 value 的概率是 min / (min + max)，值为 !value 的概率是 max / (min + max)

![“mock”](./images/mock07.png)

### 属性值是对象 Object

* 'name|count': object
  * 从属性值 object 中随机选取 count 个属性

![“mock”](./images/mock08.png)

* 'name|min-max': object
  * 从属性值 object 中随机选取 min 到 max 个属性

![“mock”](./images/mock09.png)

### 属性值是数组 Array

* 'name|1': array
  * 从属性值 array 中随机选取 1 个元素，作为最终值。

![“mock”](./images/mock10.png)

* 'name|+1': array
  * 从属性值 array 中顺序选取 1 个元素，作为最终值

![“mock”](./images/mock11.png)

* 'name|min-max': array
  * 通过重复属性值 array 生成一个新数组，重复次数大于等于 min，小于等于 max

![“mock”](./images/mock12.png)

* 'name|count': array
  * 通过重复属性值 array 生成一个新数组，重复次数为 count。

### 属性值是函数 Function

* 'name': function
  * 执行函数 function，用返回值作为属性值

![“mock”](./images/mock13.png)

### 属性值是正则表达式 RegExp

* 'name': regexp
  * 根据正则表达式生成符合它的表达式

![“mock”](./images/mock14.png)

### 属性值是时间@date

* 'name': '@date'
  * 随机创建时间 （'@date("yyyy yy y MM M dd d")'）

![“mock”](./images/mock14.png)

## 方法

### Mock.mock()

> 根据数据模板生成模拟数据

* Mock.mock( template )
  * template 需要动态生成的模拟数据的模版，并且作为返回值返回

* Mock.mock([rurl, rtype, template, function])
  * rurl 被ajax拦截的路径
    * 可以是 URL 字符串或 URL 正则
  * rtype 表示需要拦截的 Ajax 请求类型
    * GET、POST、PUT、DELETE 等
  * template 需要动态生成的模拟数据的模版，并且作为返回值返回
  * function 记录用于生成响应数据的函数。当拦截到匹配 rurl 的 Ajax 请求时，函数 function(options) 将被执行，并把执行结果作为响应数据返回

## 项目中使用方法

### jq项目

在需要用到的html页面引入mockjs，再引入你自己写的模拟数据的js，接口请求时就可以返回数据

```mockjs链接
    <script src="http://mockjs.com/dist/mock.js"></script>
```

### vue项目

在项目中安装mockjs插件，在main.js页面引入你写的mockjs的代码，这样在页面中直接请求就可以

```mockjs安装
  npm install mockjs --save-dev
```

```mock / index.js
  // 引入mockjs
  import Mock from 'mockjs'
  // 写接口返回内容
  Mock.mock()
```